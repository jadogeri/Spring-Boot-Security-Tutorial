package com.josephadogeridev.spring.security_6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurity6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
